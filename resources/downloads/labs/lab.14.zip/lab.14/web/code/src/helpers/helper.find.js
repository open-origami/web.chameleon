

function Find (ref) {
  return document. querySelector (ref)
}

export { Find }
export default Find
